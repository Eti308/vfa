VFA Encoder for macOS
=====================

Lossless, bit-exact encoder / decoder / player for float audio (.wav <-> .nx).
Everything runs locally on your Mac. Nothing is uploaded and nothing needs
to be installed.

Start it
--------
Option A, the app: double-click "VFA Encoder.app".
  It opens in its own window (Chrome/Edge/Brave/Chromium if installed,
  otherwise Safari).
  The first time, macOS may say the app "cannot be checked for malicious
  software" because it is not signed by an Apple developer. Then either
    - right-click the app -> Open -> Open (macOS 14 and earlier), or
    - System Settings -> Privacy & Security -> "Open Anyway" (macOS 15), or
    - in Terminal:  xattr -dr com.apple.quarantine "VFA Encoder.app"

Option B, no app: double-click VFA.html. It opens in your browser. Same
features, no security prompt.

Use it
------
- Drop a .wav or .nx file into the window (or Open... / Cmd-O).
- WAV: choose a level (0 fastest ... 5 default ... 8 smallest) and options,
  then "Encode to .nx". The .nx file is saved to your Downloads folder (or
  wherever you choose).
  With "Verify after encoding" each result is decoded again and compared bit
  for bit.
  Float32 WAVs are restored byte-identically. 8/16/24-bit WAVs are converted
  exactly to float32 first.
- NX: "Decode to .wav" restores the original WAV file byte for byte.
  Optionally decode only an excerpt (from / length in seconds).
- Player: play/pause (space bar), drag the waveform or the scrubber, +-10 s
  buttons, arrow keys +-5 s, loop, volume.
  Files above 0 dBFS are normalized for listening only; the files are never
  changed.
- Command line at the bottom: type the same options as the `vfa` CLI, e.g.
      --level 8 --no-stereo
      --block 4096 --fixed-blocks
      encode --level 2
      decode --start-time 30 --duration 10
      help
  Options typed there update the controls and vice versa. Up/down arrows
  recall previous commands.
